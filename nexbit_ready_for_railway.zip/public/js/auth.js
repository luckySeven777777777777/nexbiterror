function saveToken(data){ localStorage.setItem('nexbit_admin', JSON.stringify(data)); }
function getToken(){ try{ return JSON.parse(localStorage.getItem('nexbit_admin')); }catch(e){return null;} }
function clearToken(){ localStorage.removeItem('nexbit_admin'); }
function ensureLoggedIn(){ const t = getToken(); if(!t){ window.location.href='/login.html'; return null } return t; }