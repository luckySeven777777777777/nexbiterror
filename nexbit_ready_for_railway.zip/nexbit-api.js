const fetch = global.fetch || require('node-fetch');
module.exports.sendMessage = async function(chatId, text){
  const token = process.env.ADMIN_BOT_TOKEN || process.env.BOT_TOKEN;
  if(!token) throw new Error('No bot token in env');
  const resp = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ chat_id: chatId, text, parse_mode:'HTML' })
  });
  const j = await resp.json();
  if(!j.ok) throw new Error(JSON.stringify(j));
  return j;
};