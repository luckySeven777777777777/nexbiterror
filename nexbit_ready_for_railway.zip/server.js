require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const session = require('express-session');
const cors = require('cors');
const auth = require('./auth');
const nexbit = require('./nexbit-api');

const app = express();
const DB_FILE = path.join(__dirname, 'database.json');

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'nexbit_session_secret_change_me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24*60*60*1000 }
}));

app.use(express.static(path.join(__dirname, 'public')));

function readDB(){ try{ return JSON.parse(fs.readFileSync(DB_FILE)); }catch(e){ return { admins:[], users:[], balances:{}, deposits:[], withdrawals:[] }; } }
function writeDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

app.post('/api/login', auth.login);
app.get('/api/logout', auth.logout);
app.get('/api/me', auth.requireAuth, auth.me);

app.get('/api/admins', auth.requireAuth, (req,res)=>{
  const db = readDB();
  res.json({ success:true, admins: db.admins });
});

app.post('/api/admins', auth.requireAuth, (req,res)=>{
  const { username, password, role } = req.body;
  if(!username || !password) return res.json({ success:false, message:'missing fields' });
  const db = readDB();
  const id = Date.now();
  db.admins.push({ id, username, password, role: role||'admin' });
  writeDB(db);
  res.json({ success:true, admin:{ id, username, role } });
});

app.delete('/api/admins/:id', auth.requireAuth, (req,res)=>{
  const db = readDB();
  db.admins = db.admins.filter(a => String(a.id) !== String(req.params.id));
  writeDB(db);
  res.json({ success:true });
});

app.get('/api/users', auth.requireAuth, (req,res)=>{
  const db = readDB();
  res.json({ success:true, users: db.users });
});

app.post('/api/users', auth.requireAuth, (req,res)=>{
  const db = readDB();
  const u = { id: Date.now(), ...req.body };
  db.users.push(u); writeDB(db);
  res.json({ success:true, user:u });
});

app.post('/api/balance/add', auth.requireAuth, (req,res)=>{
  const { userId, amount } = req.body;
  const db = readDB();
  db.balances = db.balances || {};
  db.balances[userId] = (db.balances[userId]||0) + Number(amount||0);
  writeDB(db);
  res.json({ success:true, balance: db.balances[userId] });
});

app.post('/api/balance/sub', auth.requireAuth, (req,res)=>{
  const { userId, amount } = req.body;
  const db = readDB();
  db.balances = db.balances || {};
  db.balances[userId] = (db.balances[userId]||0) - Number(amount||0);
  writeDB(db);
  res.json({ success:true, balance: db.balances[userId] });
});

app.post('/api/deposits', auth.requireAuth, (req,res)=>{
  const db = readDB();
  const d = { id: Date.now(), ...req.body, status:'pending' };
  db.deposits.push(d); writeDB(db);
  if(process.env.MARKET_PUSH_CHAT_ID) nexbit.sendMessage(process.env.MARKET_PUSH_CHAT_ID, `New deposit ${d.id}`).catch(()=>{});
  res.json({ success:true, deposit:d });
});

app.post('/api/withdrawals', auth.requireAuth, (req,res)=>{
  const db = readDB();
  const w = { id: Date.now(), ...req.body, status:'pending' };
  db.withdrawals.push(w); writeDB(db);
  if(process.env.MARKET_PUSH_CHAT_ID) nexbit.sendMessage(process.env.MARKET_PUSH_CHAT_ID, `New withdrawal ${w.id}`).catch(()=>{});
  res.json({ success:true, withdrawal:w });
});

app.post('/api/send', auth.requireAuth, async (req,res)=>{
  const { chatId, text } = req.body;
  try { await nexbit.sendMessage(chatId, text); res.json({ success:true }); } catch(e){ res.status(500).json({ success:false, error:String(e) }); }
});

app.get('*', (req,res)=>{ res.sendFile(path.join(__dirname, 'public', 'index.html')); });

const PORT = process.env.PORT || 3006;
app.listen(PORT, ()=> console.log('Nexbit backend running on port', PORT));
