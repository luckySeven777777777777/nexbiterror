const fs = require('fs');
const path = require('path');
const DB_FILE = path.join(__dirname, 'database.json');
function readDB(){ try { return JSON.parse(fs.readFileSync(DB_FILE)); } catch(e){ return { admins:[] }; } }
function writeDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
exports.login = (req,res) => {
  const { username, password } = req.body || {};
  const db = readDB();
  const admin = (db.admins||[]).find(a=>a.username===username && a.password===password);
  if(!admin) return res.status(401).json({ success:false, message:'Invalid username or password' });
  req.session.admin = { id: admin.id, username: admin.username, role: admin.role };
  return res.json({ success:true, token: 'admin-token-1', user: { id: admin.id, username: admin.username, role: admin.role } });
};
exports.logout = (req,res) => { req.session.destroy(()=>{}); res.json({ success:true }); };
exports.requireAuth = (req,res,next) => {
  if(req.session && req.session.admin) return next();
  const auth = req.headers['authorization'] || '';
  if(auth.startsWith('Bearer ')) {
    const token = auth.slice(7).trim();
    if(token === 'admin-token-1') { return next(); }
  }
  return res.status(401).json({ success:false, message:'Unauthorized' });
};
exports.me = (req,res) => {
  if(req.session && req.session.admin) return res.json({ success:true, user: req.session.admin });
  return res.json({ success:false });
};
