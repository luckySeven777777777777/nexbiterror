const fs = require("fs");

function loadDB() {
    return JSON.parse(fs.readFileSync("./database.json"));
}

exports.login = (req, res) => {
    const { username, password } = req.body;

    const db = loadDB();
    const admin = db.admins.find(u => u.username === username && u.password === password);

    if (!admin) {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
    }

    // 保存 session
    req.session.user = {
        id: admin.id,
        username: admin.username,
        role: admin.role
    };

    res.json({ success: true, user: req.session.user });
};

exports.logout = (req, res) => {
    req.session.destroy(() => {
        res.json({ success: true });
    });
};

exports.requireAuth = (req, res, next) => {
    if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Not logged in" });
    }
    next();
};

exports.me = (req, res) => {
    res.json({ success: true, user: req.session.user });
};
