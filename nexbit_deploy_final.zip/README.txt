Nexbit fixed deploy package - contains restored API endpoints and admin pages.
