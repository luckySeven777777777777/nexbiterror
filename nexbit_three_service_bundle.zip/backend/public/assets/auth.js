// public/auth.js - 前端统一登录控制 + token 管理
console.log('[auth] loaded');

// 保存 token
function saveToken(token) {
  localStorage.setItem('nexbit_token', token);
}
// 取 token
function getToken() {
  return localStorage.getItem('nexbit_token');
}
// 清除 token + session info
function clearToken() {
  localStorage.removeItem('nexbit_token');
  localStorage.removeItem('nexbit_user');
}
// 保存用户名（可选）
function saveUser(u) { localStorage.setItem('nexbit_user', u); }
function getUser() { return localStorage.getItem('nexbit_user'); }

// 全局 api 封装（自动带 token & JSON）
async function api(url, options = {}) {
  const token = getToken();
  options.headers = options.headers || {};
  if (!options.headers['Content-Type']) options.headers['Content-Type'] = 'application/json';
  if (token) options.headers['Authorization'] = 'Bearer ' + token;

  let res;
  try {
    res = await fetch(url, options);
  } catch (e) {
    console.error('[auth] network error', e);
    alert('网络异常，无法联系服务器');
    return {};
  }
  if (res.status === 401) {
    clearToken();
    window.location.href = '/login.html';
    return {};
  }
  try { return await res.json(); } catch (e) { return {}; }
}

// 页面必须登录才能访问
function requireLogin() {
  const token = getToken();
  if (!token) {
    window.location.href = '/login.html';
    return false;
  }
  return true;
}
