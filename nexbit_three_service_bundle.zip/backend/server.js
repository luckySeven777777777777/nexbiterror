
// Nexbit full API server - rebuilt to restore missing admin APIs and bot endpoints
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const session = require('express-session');
const crypto = require('crypto');

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: process.env.SESSION_SECRET || 'nexbit_secret', resave: false, saveUninitialized: true }));

// paths
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(__dirname, 'database.json');
const SESS_FILE = path.join(__dirname, 'data', 'sessions.json');

// ensure data dir
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

// load or init database.json
let DB = {};
try {
    if (fs.existsSync(DB_FILE)) {
        DB = JSON.parse(fs.readFileSync(DB_FILE, 'utf8') || '{}');
    } else {
        DB = {
            admins: [{ username: 'admin', password: '444721', email: 'admin@example.com', isSuper: true }],
            settings: {
                telegramBotToken: process.env.ADMIN_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN || '',
                telegramAdminChatId: process.env.ADMIN_CHAT_ID || process.env.TELEGRAM_ADMIN_CHAT_ID || '',
                tgThresholdCount: 5,
                tgWindowSeconds: 3600,
                sessionSecret: process.env.SESSION_SECRET || 'nexbit_session_secret_change_me'
            },
            users: [],
            deposits: [],
            withdrawals: [],
            logs: []
        };
        fs.writeFileSync(DB_FILE, JSON.stringify(DB, null, 2));
    }
} catch (e) {
    console.error('DB load error', e);
    DB = {};
}

// sessions store (simple token -> username)
let SESSIONS = {};
try {
    if (fs.existsSync(SESS_FILE)) {
        SESSIONS = JSON.parse(fs.readFileSync(SESS_FILE, 'utf8') || '{}');
    }
} catch (e) { SESSIONS = {}; }

function saveDB() {
    fs.writeFileSync(DB_FILE, JSON.stringify(DB, null, 2));
}
function saveSessions() {
    fs.writeFileSync(SESS_FILE, JSON.stringify(SESSIONS, null, 2));
}

function genToken() {
    return crypto.randomBytes(24).toString('hex');
}

// load bot helper if exists
let botHelper = null;
try {
    botHelper = require('./bot');
} catch (e) {
    console.warn('bot helper not found or failed to load, bot functions disabled.');
}

// middleware: requireAuth for API
function requireAuth(req, res, next) {
    // accept Authorization: Bearer <token>
    const auth = req.headers['authorization'];
    if (auth && auth.startsWith('Bearer ')) {
        const token = auth.slice(7).trim();
        const username = SESSIONS[token];
        if (username) {
            req.user = { username };
            return next();
        }
    }
    // also accept cookie session
    if (req.session && req.session.username) {
        req.user = { username: req.session.username };
        return next();
    }
    return res.status(401).json({ message: 'Unauthorized' });
}

// serve static public files
app.use(express.static(path.join(__dirname, 'public')));

// pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-new.html'));
});

// API - status
app.get('/api/status', (req, res) => {
    res.json({ status: 'ok', time: new Date() });
});

// API - login
app.post('/api/login', (req, res) => {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ message: 'Missing username or password' });
    const admin = (DB.admins || []).find(a => a.username === username && a.password === password);
    if (!admin) return res.status(401).json({ message: 'Invalid credentials' });
    // generate token
    const token = genToken();
    SESSIONS[token] = username;
    saveSessions();
    // set session cookie as well
    req.session.username = username;
    // optional bot notify
    if (botHelper && botHelper.sendLoginNotify) {
        botHelper.sendLoginNotify(username, req.ip).catch(()=>{});
    }
    res.json({ token, username });
});

// API - logout
app.post('/api/logout', requireAuth, (req, res) => {
    // remove token if provided
    const auth = req.headers['authorization'];
    if (auth && auth.startsWith('Bearer ')) {
        const token = auth.slice(7).trim();
        delete SESSIONS[token];
        saveSessions();
    }
    if (req.session) {
        req.session.destroy(()=>{});
    }
    res.json({ ok: true });
});

// API - me
app.get('/api/me', requireAuth, (req, res) => {
    const username = req.user && req.user.username;
    const admin = (DB.admins || []).find(a => a.username === username);
    res.json({ username, admin: admin || null });
});

// Admin management routes
app.get('/api/admins', requireAuth, (req, res) => {
    res.json(DB.admins || []);
});
app.post('/api/admins', requireAuth, (req, res) => {
    const { username, password, email, isSuper } = req.body || {};
    if (!username || !password) return res.status(400).json({ message: 'missing' });
    const exists = (DB.admins || []).find(a => a.username === username);
    if (exists) return res.status(400).json({ message: 'admin exists' });
    const newAdmin = { username, password, email: email || '', isSuper: !!isSuper };
    DB.admins = DB.admins || [];
    DB.admins.push(newAdmin);
    saveDB();
    res.json(newAdmin);
});
app.delete('/api/admins/:username', requireAuth, (req, res) => {
    const uname = req.params.username;
    DB.admins = (DB.admins || []).filter(a => a.username !== uname);
    saveDB();
    res.json({ ok: true });
});

// Users (members) management
app.get('/api/users', requireAuth, (req, res) => {
    res.json(DB.users || []);
});
app.post('/api/users', requireAuth, (req, res) => {
    const u = req.body;
    if (!u || !u.username) return res.status(400).json({ message: 'invalid user' });
    u.id = Date.now();
    DB.users = DB.users || [];
    DB.users.push(u);
    saveDB();
    res.json(u);
});
app.delete('/api/users/:id', requireAuth, (req, res) => {
    const id = Number(req.params.id);
    DB.users = (DB.users || []).filter(x => x.id !== id);
    saveDB();
    res.json({ ok: true });
});

// Deposits & Withdrawals
app.get('/api/deposits', requireAuth, (req, res) => res.json(DB.deposits || []));
app.post('/api/deposits', requireAuth, (req, res) => {
    const d = req.body;
    d.id = Date.now();
    d.status = 'pending';
    DB.deposits = DB.deposits || [];
    DB.deposits.push(d);
    saveDB();
    if (botHelper && botHelper.sendDepositNotify) botHelper.sendDepositNotify(d.id, d.amount, d.currency, d.member).catch(()=>{});
    res.json(d);
});
app.post('/api/deposits/:id/status', requireAuth, (req, res) => {
    const id = Number(req.params.id);
    const { status } = req.body;
    DB.deposits = (DB.deposits || []).map(x => x.id === id ? Object.assign(x, { status }) : x);
    saveDB();
    res.json({ ok: true });
});

app.get('/api/withdrawals', requireAuth, (req, res) => res.json(DB.withdrawals || []));
app.post('/api/withdrawals', requireAuth, (req, res) => {
    const w = req.body;
    w.id = Date.now();
    w.status = 'pending';
    DB.withdrawals = DB.withdrawals || [];
    DB.withdrawals.push(w);
    saveDB();
    if (botHelper && botHelper.sendWithdrawRequest) botHelper.sendWithdrawRequest(w.id, w.amount, w.currency, w.member).catch(()=>{});
    res.json(w);
});
app.post('/api/withdrawals/:id/status', requireAuth, (req, res) => {
    const id = Number(req.params.id);
    const { status } = req.body;
    DB.withdrawals = (DB.withdrawals || []).map(x => x.id === id ? Object.assign(x, { status }) : x);
    saveDB();
    res.json({ ok: true });
});

// Settings
app.get('/api/settings', requireAuth, (req, res) => res.json(DB.settings || {}));
app.post('/api/settings', requireAuth, (req, res) => {
    DB.settings = Object.assign(DB.settings || {}, req.body || {});
    saveDB();
    res.json(DB.settings);
});

// Backup endpoint (just copies database.json to backups folder)
app.post('/api/backup', requireAuth, (req, res) => {
    try {
        const backupsDir = path.join(__dirname, 'data', 'backups');
        if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
        const name = 'db-backup-' + new Date().toISOString().replace(/[:.]/g,'-') + '.json';
        fs.copyFileSync(DB_FILE, path.join(backupsDir, name));
        res.json({ ok: true, name });
    } catch (e) {
        res.status(500).json({ message: 'backup failed', error: String(e) });
    }
});

// Bot control endpoints
app.get('/api/bot/status', requireAuth, (req, res) => {
    res.json({ enabled: !!(botHelper && botHelper.botInstance) });
});
app.post('/api/bot/start', requireAuth, (req, res) => {
    // start not supported for node-telegram-bot-api in server side if using polling; placeholder
    res.json({ ok: true, message: 'start endpoint placeholder' });
});
app.post('/api/bot/stop', requireAuth, (req, res) => {
    res.json({ ok: true, message: 'stop endpoint placeholder' });
});

// 2FA placeholders
app.post('/api/2fa/setup', requireAuth, (req, res) => {
    // placeholder return secret
    res.json({ secret: 'PLACEHOLDER-2FA-SECRET' });
});
app.post('/api/2fa/verify', requireAuth, (req, res) => {
    res.json({ ok: true, verified: true });
});

// simple change password endpoint for admin
app.post('/api/change-login-password', requireAuth, (req, res) => {
    const username = req.user && req.user.username;
    const { oldPassword, newPassword } = req.body || {};
    const admin = (DB.admins || []).find(a => a.username === username);
    if (!admin) return res.status(404).json({ message: 'admin not found' });
    if (admin.password !== oldPassword) return res.status(400).json({ message: 'old password mismatch' });
    admin.password = newPassword;
    saveDB();
    res.json({ ok: true });
});

// catch-all for unknown api
app.use('/api/*', (req, res) => {
    res.status(404).json({ message: 'Not found' });
});

// start
app.listen(PORT, () => {
    console.log('Server running on port', PORT);
});
