Backend service for Nexbit: run `npm install` then `npm start`.
Configure env vars in environment or .env:
BOT_TOKEN, ADMIN_BOT_TOKEN, ADMIN_IDS, MARKET_PUSH_CHAT_ID, ADMIN_CHAT_ID, PORT, SESSION_SECRET
