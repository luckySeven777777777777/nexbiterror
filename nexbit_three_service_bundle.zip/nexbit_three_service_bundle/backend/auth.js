// auth.js — FINAL VERSION
// -------------------------------

const fs = require("fs");

const users = JSON.parse(fs.readFileSync("./database.json"));

module.exports = {

    login: (req, res) => {
        const { username, password } = req.body;

        const admin = users.admins.find(
            u => u.username === username && u.password === password
        );

        if (!admin) {
            return res.json({ success: false, message: "Invalid login" });
        }

        req.session.user = {
            id: admin.id,
            username: admin.username,
            role: admin.role
        };

        return res.json({ success: true, message: "Login successful" });
    },

    logout: (req, res) => {
        req.session.destroy(() => {
            res.json({ success: true });
        });
    },

    requireAuth: (req, res, next) => {
        if (!req.session.user) {
            return res.status(401).json({ error: "Not logged in" });
        }
        next();
    },

    me: (req, res) => {
        res.json({
            success: true,
            user: req.session.user
        });
    }
};
