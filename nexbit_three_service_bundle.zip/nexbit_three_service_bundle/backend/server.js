// server.js — FINAL VERSION (No Telegram Bot here, only API server)
// ---------------------------------------------

require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const cors = require('cors');

const auth = require('./auth');
const apiRoutes = require('./nexbit-api');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session
app.use(
    session({
        secret: process.env.SESSION_SECRET || "nexbit_session_secret_change_me",
        resave: false,
        saveUninitialized: true,
        cookie: { maxAge: 24 * 60 * 60 * 1000 }
    })
);

// ---------------------------------------------
// STATIC FRONTEND (Admin Panel)
// ---------------------------------------------
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public/index.html"));
});

app.get("/login", (req, res) => {
    res.sendFile(path.join(__dirname, "public/login.html"));
});

// ---------------------------------------------
// AUTH ROUTES
// ---------------------------------------------
app.post("/api/login", auth.login);
app.get("/api/logout", auth.logout);
app.get("/api/me", auth.requireAuth, auth.me);

// ---------------------------------------------
// BACKEND API
// ---------------------------------------------
app.use("/api", auth.requireAuth, apiRoutes);

// ---------------------------------------------
const PORT = process.env.PORT || 3006;

app.listen(PORT, () => {
    console.log("=====================================");
    console.log("🚀 Nexbit Backend Server Running");
    console.log("📡 PORT:", PORT);
    console.log("🤖 Backend Bot (send-only) enabled");
    console.log("=====================================");
});
