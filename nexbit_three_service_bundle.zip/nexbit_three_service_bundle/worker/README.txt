Python worker bot: install requirements and run worker.py. Set BOT_TOKEN env.
