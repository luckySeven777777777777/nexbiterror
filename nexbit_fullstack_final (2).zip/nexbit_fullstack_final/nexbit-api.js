// nexbit-api.js — FINAL VERSION (No polling bot, only send messages)
// -----------------------------------------------------------------

const express = require("express");
const fs = require("fs");
const router = express.Router();
const axios = require("axios");

const DB_PATH = "./database.json";

// ---------------------------------------------
// Load DB
// ---------------------------------------------
function loadDB() {
    return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(db) {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ---------------------------------------------
// Telegram sender (USES BOT B TOKEN)
// ---------------------------------------------
async function sendTelegramMessage(chat_id, text) {
    try {
        await axios.post(`https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`, {
            chat_id,
            text
        });
    } catch (err) {
        console.log("Telegram send error:", err.message);
    }
}

// ---------------------------------------------
// USER MANAGEMENT
// ---------------------------------------------
router.get("/users", (req, res) => {
    const db = loadDB();
    res.json(db.users);
});

router.post("/user/balance/add", (req, res) => {
    const { user_id, amount } = req.body;

    const db = loadDB();
    const user = db.users.find(u => u.id == user_id);

    if (!user) return res.json({ success: false });

    user.balance += Number(amount);
    saveDB(db);

    sendTelegramMessage(process.env.ADMIN_CHAT_ID, `💰 Added ${amount} to user ${user.username}`);

    res.json({ success: true });
});

router.post("/user/balance/sub", (req, res) => {
    const { user_id, amount } = req.body;

    const db = loadDB();
    const user = db.users.find(u => u.id == user_id);

    if (!user) return res.json({ success: false });

    user.balance -= Number(amount);
    saveDB(db);

    sendTelegramMessage(process.env.ADMIN_CHAT_ID, `💸 Deducted ${amount} from user ${user.username}`);

    res.json({ success: true });
});

// ---------------------------------------------
// ADMIN MANAGEMENT
// ---------------------------------------------
router.get("/admins", (req, res) => {
    const db = loadDB();
    res.json(db.admins);
});

// More routes can be added...

module.exports = router;
