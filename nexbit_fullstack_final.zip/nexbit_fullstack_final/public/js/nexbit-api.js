// public/js/nexbit-api-client.js - client-only helper (move to public/js)
(function(){
  const API = {};
  const JSON_HEADERS = {'Content-Type':'application/json'};

  async function fetchJson(url, opts = {}) {
    opts.credentials = opts.credentials || 'include';
    if (!opts.headers) opts.headers = {};
    opts.headers = Object.assign({}, opts.headers, opts.headers || {});
    const res = await fetch(url, opts);
    const text = await res.text();
    let j = null;
    try { j = text ? JSON.parse(text) : null; } catch(e){ j = null; }
    if (!res.ok) {
      throw j && j.message ? j : { message: j && j.message ? j.message : `HTTP ${res.status}` };
    }
    return j === null ? {} : j;
  }

  // Expose simplified methods (client will call server endpoints listed in server.js)
  API.login = (username, password) => fetchJson('/api/login', { method: 'POST', headers: JSON_HEADERS, body: JSON.stringify({username,password}) });
  API.logout = () => fetchJson('/api/logout', { method: 'POST' });
  API.me = () => fetchJson('/api/me');

  API.listAdmins = () => fetchJson('/api/users');
  API.createAdmin = (username,password,role='admin',email=null,is_super=0) => fetchJson('/api/users', { method:'POST', headers: JSON_HEADERS, body: JSON.stringify({username,password,role,email,is_super}) });
  API.deleteAdmin = (id) => fetchJson(`/api/users/${id}`, { method:'DELETE' });

  // UI bindings simplified (you can use these)
  window.NexbitClient = { API };
})();
