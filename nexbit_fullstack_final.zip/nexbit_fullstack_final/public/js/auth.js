// 保存登录信息（含 token）
function saveToken(data){
    localStorage.setItem("admin", JSON.stringify(data));
}

// 取得已登录管理员信息
function getUser(){
    return JSON.parse(localStorage.getItem("admin"));
}

// 清除登录信息
function clearUser(){
    localStorage.removeItem("admin");
}

// 检查是否登录（没登录跳转登录页）
function ensureLoggedIn(){
    const user = getUser();
    if (!user || !user.token) {
        clearUser();
        window.location.href = "/login.html";
        return null;
    }
    return user;
}
