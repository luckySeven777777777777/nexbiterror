// public/js/auth.js - client-side login/session helpers
function saveToken(data){
  localStorage.setItem('admin', JSON.stringify(data));
}

function getUser(){
  return JSON.parse(localStorage.getItem('admin'));
}

function clearUser(){
  localStorage.removeItem('admin');
}

function ensureLoggedIn(){
  const user = getUser();
  if(!user) {
    window.location.href = '/login.html';
    return null;
  }
  return user;
}

// wrapper for API calls that uses fetch and sends cookies (sessions)
async function apiRequest(path, options = {}) {
  options.credentials = 'include'; // include cookies (session)
  options.headers = options.headers || {};
  if(!options.headers['Content-Type'] && !(options.body instanceof FormData)) {
    options.headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(path, options);
  if(res.status === 401) {
    clearUser();
    window.location.href = '/login.html';
    throw new Error('Unauthorized');
  }
  const text = await res.text();
  try {
    return JSON.parse(text || '{}');
  } catch(e) {
    return text;
  }
}
