const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();

// ------------------ SESSION ------------------
app.use(
    session({
        secret: process.env.SESSION_SECRET || "nexbit_session_secret",
        resave: false,
        saveUninitialized: false,
        cookie: { maxAge: 24 * 60 * 60 * 1000 }
    })
);

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "public")));

// ------------------ DB ------------------
function loadDB() {
    return JSON.parse(fs.readFileSync("./database.json"));
}
function saveDB(db) {
    fs.writeFileSync("./database.json", JSON.stringify(db, null, 2));
}

// ------------------ LOGIN API ------------------
app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    const db = loadDB();

    const admin = db.admins.find(a => a.username === username && a.password === password);

    if (!admin) {
        return res.json({ success: false, message: "账号或密码错误" });
    }

    // 生成 token
    const token = "token_" + Date.now();
    admin.token = token;
    saveDB(db);

    res.json({ success: true, token });
});

// ------------------ Middleware: Auth ------------------
function requireAuth(req, res, next) {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) return res.status(401).json({ success: false, message: "Unauthorized" });

    const db = loadDB();
    const admin = db.admins.find(a => a.token === token);
    if (!admin) return res.status(401).json({ success: false });

    req.admin = admin;
    next();
}

// ------------------ GET CURRENT USER ------------------
app.get("/api/me", requireAuth, (req, res) => {
    res.json({
        success: true,
        admin: {
            id: req.admin.id,
            username: req.admin.username,
            role: req.admin.role
        }
    });
});

// ------------------ ADMIN LIST ------------------
app.get("/api/admins", requireAuth, (req, res) => {
    const db = loadDB();
    res.json({ success: true, admins: db.admins });
});

// ------------------ ADD ADMIN ------------------
app.post("/api/admins/add", requireAuth, (req, res) => {
    const db = loadDB();
    const { username, password, role } = req.body;

    if (!username || !password)
        return res.json({ success: false, message: "缺少字段" });

    db.admins.push({
        id: Date.now(),
        username,
        password,
        role: role || "admin"
    });

    saveDB(db);

    res.json({ success: true });
});

// ------------------ FALLBACK ------------------
app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// ------------------ START ------------------
const PORT = process.env.PORT || 3006;
app.listen(PORT, () => console.log("Server running on port " + PORT));
