// server.js - express 接口 + 静态文件（用于 Railway 部署）
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const serverNexbit = require('./nexbit-api-server'); // <-- server-side API helper (see file below)
const auth = require('./auth-server'); // <-- server-side auth middleware (see file below)

const app = express();

// session config (use env variable for secret in production)
app.use(session({
  secret: process.env.SESSION_SECRET || 'nexbit_session_secret_change_me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// serve static admin UI (place your html/css/js under public/)
app.use(express.static(path.join(__dirname, 'public')));

// --- AUTH ROUTES (server-side) ---
app.post('/api/login', auth.login);       // expects JSON { username, password }, returns { success, token, user }
app.post('/api/logout', auth.logout);
app.get('/api/me', auth.requireAuth, auth.me);

// --- ADMIN CRUD (example endpoints used by client)
app.get('/api/users', auth.requireAuth, (req, res) => {
  const db = JSON.parse(fs.readFileSync(path.join(__dirname, 'database.json')));
  res.json({ success: true, users: db.admins });
});

app.post('/api/users', auth.requireAuth, (req, res) => {
  const dbPath = path.join(__dirname, 'database.json');
  const db = JSON.parse(fs.readFileSync(dbPath));
  const { username, password, role, email, is_super } = req.body;
  if(!username || !password) return res.json({ success: false, message: 'Missing fields' });
  const newAdmin = {
    id: Date.now(),
    username,
    password,
    role: role || 'admin',
    email: email || '',
    is_super: !!is_super,
    created_at: new Date().toISOString()
  };
  db.admins.push(newAdmin);
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
  res.json({ success: true, user: newAdmin });
});

app.delete('/api/users/:id', auth.requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const dbPath = path.join(__dirname, 'database.json');
  const db = JSON.parse(fs.readFileSync(dbPath));
  db.admins = db.admins.filter(a => a.id !== id);
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
  res.json({ success: true });
});

// --- Example: Nexbit send message endpoint (server-side) ---
app.post('/api/send', auth.requireAuth, async (req, res) => {
  try {
    const r = await serverNexbit.sendMessage(req.body);
    res.json({ success: true, result: r });
  } catch (err) {
    console.error('send error', err);
    res.status(500).json({ success: false, message: err.message || String(err) });
  }
});

// --- fallback: SPA routes / serve index.html ---
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- start server ---
// IMPORTANT: Railway provides PORT via process.env.PORT. Do NOT hardcode PORT in env on Railway.
const PORT = process.env.PORT || 3006;
app.listen(PORT, () => console.log('Server running on port', PORT));
