
require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const DB_FILE = path.join(__dirname, "database.json");

// 加载数据库
let DB = { admins: [], users: [], deposits: [], withdrawals: [] };
if (fs.existsSync(DB_FILE)) {
    DB = JSON.parse(fs.readFileSync(DB_FILE));
} else {
    DB = {
        admins: [{ id: 1, username: "admin", password: "444721" }],
        users: [],
        deposits: [],
        withdrawals: []
    };
}

// 保存 DB
function saveDB() {
    fs.writeFileSync(DB_FILE, JSON.stringify(DB, null, 2));
}

// ------------- 登录 -----------------
app.post("/api/login", function(req, res) {
    const { username, password } = req.body;
    const admin = DB.admins.find(a => a.username === username && a.password === password);
    if (!admin) return res.status(401).json({ ok: false, message: "Invalid login" });
    return res.json({ ok: true, token: "OK", admin });
});

// ------------- 获取管理员列表 -----------------
app.get("/api/admins", (req, res) => {
    res.json({ ok: true, admins: DB.admins });
});

// 添加管理员
app.post("/api/admins", (req, res) => {
    const { username, password } = req.body;
    const admin = { id: Date.now(), username, password };
    DB.admins.push(admin);
    saveDB();
    res.json({ ok: true, admin });
});

// 删除管理员
app.delete("/api/admins/:id", (req, res) => {
    DB.admins = DB.admins.filter(a => String(a.id) !== req.params.id);
    saveDB();
    res.json({ ok: true });
});

// ------------- 充值 / 提现 -----------------
app.post("/api/deposits", (req, res) => {
    const dep = { id: Date.now(), ...req.body, status: "pending" };
    DB.deposits.push(dep);
    saveDB();
    res.json({ ok: true, deposit: dep });
});

app.post("/api/withdrawals", (req, res) => {
    const w = { id: Date.now(), ...req.body, status: "pending" };
    DB.withdrawals.push(w);
    saveDB();
    res.json({ ok: true, withdrawal: w });
});

// ========== 静态前端 =============
app.use(express.static(path.join(__dirname, "public")));
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.get("*", (req, res) =>
    res.sendFile(path.join(__dirname, "public", "index.html"))
);

const PORT = process.env.PORT || 3006;
app.listen(PORT, () => console.log("✔ Fullstack backend running at port", PORT));
