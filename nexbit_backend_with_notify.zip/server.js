
const express = require('express');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3006;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// simple DB file
const DB_FILE = path.join(__dirname, 'database.json');
let DB = { admins: [{username:'admin', password:'444721'}], users: [], deposits: [], withdrawals: [], settings: {} };
try { if (fs.existsSync(DB_FILE)) DB = JSON.parse(fs.readFileSync(DB_FILE)); else fs.writeFileSync(DB_FILE, JSON.stringify(DB, null,2)); } catch(e){ console.error('db load', e); }

// Helper: send Telegram via ADMIN_BOT_TOKEN (HTTP API) - no polling, safe for backend
async function sendTelegram(chatId, text) {
  const token = process.env.ADMIN_BOT_TOKEN;
  if(!token) return;
  try {
    // Node 18+ has global fetch
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: text, parse_mode: 'HTML' })
    });
  } catch(e) {
    console.error('sendTelegram error', e);
  }
}

// Auth/login simple
app.post('/api/login', (req,res) => {
  const { username, password } = req.body || {};
  const admin = (DB.admins||[]).find(a=>a.username===username && a.password===password);
  if(!admin) return res.status(401).json({ ok:false, message:'invalid' });
  return res.json({ ok:true, token: 'dummy-token', username });
});

// deposits
app.post('/api/deposits', async (req,res) => {
  const d = req.body || {};
  d.id = Date.now();
  d.status = 'pending';
  DB.deposits = DB.deposits || [];
  DB.deposits.push(d);
  fs.writeFileSync(DB_FILE, JSON.stringify(DB, null,2));
  // notify admin via ADMIN_BOT_TOKEN if set
  const adminChat = process.env.MARKET_PUSH_CHAT_ID || process.env.ADMIN_CHAT_ID;
  if(adminChat) {
    const msg = `🔔 新充值请求\n会员: ${d.member || d.user || 'unknown'}\n金额: ${d.amount || d.value}\n币种: ${d.currency || d.coin || ''}\n订单: ${d.id}`;
    await sendTelegram(adminChat, msg);
  }
  res.json({ ok:true, deposit:d });
});

// withdrawals
app.post('/api/withdrawals', async (req,res) => {
  const w = req.body || {};
  w.id = Date.now();
  w.status = 'pending';
  DB.withdrawals = DB.withdrawals || [];
  DB.withdrawals.push(w);
  fs.writeFileSync(DB_FILE, JSON.stringify(DB, null,2));
  const adminChat = process.env.MARKET_PUSH_CHAT_ID || process.env.ADMIN_CHAT_ID;
  if(adminChat) {
    const msg = `🔔 新提款请求\n会员: ${w.member || w.user || 'unknown'}\n金额: ${w.amount || w.value}\n币种: ${w.currency || w.coin || ''}\n订单: ${w.id}`;
    await sendTelegram(adminChat, msg);
  }
  res.json({ ok:true, withdrawal:w });
});

// settings endpoints (get/save)
app.get('/api/settings', (req,res)=> res.json({ ok:true, settings: DB.settings || {} }));
app.post('/api/settings', (req,res)=> { DB.settings = Object.assign(DB.settings||{}, req.body||{}); fs.writeFileSync(DB_FILE, JSON.stringify(DB, null,2)); res.json({ ok:true, settings: DB.settings }); });

// static pages
app.get('/', (req,res)=> res.sendFile(path.join(__dirname,'public','index.html')));
app.get('/login', (req,res)=> res.sendFile(path.join(__dirname,'public','login.html')));

app.listen(PORT, ()=> console.log('Server running on port', PORT));
